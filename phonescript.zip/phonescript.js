






var mobobj=[{
    img :"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/2C/CE/5805d750-731a-47ea-85f7-52c6cd2fcbf2.jpg.webp",
    mob_name:"Xioami Redmi Note 11 Global",
    price:"₹13908.86",
    strikeoff_price:"26341.45"
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/75/9C/b1ebd629-1853-4242-bf48-ad89f26f489a.jpg.webp",
    mob_name:"DOOGEE V20 Global Version Dual",
    price:"₹38,850.78",
    strikeoff_price:"₹46,621.091",
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/09/79/399e192a-d21c-4008-979c-5a840f8c857f.jpg.webp",
    mob_name:"POCO F3 Global Version 6.67 inch",
    price:"₹31,003.54",
    strikeoff_price:"₹41,104.94",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/9F/2B/8c5285ce-de67-411a-a8a0-d70b3e1576cd.jpg.webp",
    mob_name:"POCO F3 Global Version 6.67 inch",
    price:"₹34,965.62",
    strikeoff_price:"₹44,213.07",
    
    },
    {
    img:"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/9C/B3/e8fe90f9-e578-4584-b9a8-8740814ed989.jpg.webp",
    mob_name:"POCO X4 Pro 5G Global Version",
    price:"₹26,341.35",
    strikeoff_price:"₹33,334.63",
    
    },
    {
    img:"https://imgaz2.staticbg.com/thumb/gallery/oaupload/banggood/images/7C/E6/adb2b914-4774-44a6-83fb-0e22a3c2cc4d.jpg.webp",
    mob_name:"One Plus 9 5G Global Rom 12GB",
    price:"₹58,976.66",
    strikeoff_price:"₹65,192.91",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/C4/98/d373c574-0223-4ddb-b978-9c02b65a315e.png.webp",
    mob_name:"Ulefone Power Armor 13 13200mAh",
    price:"₹31,080.47",
    strikeoff_price:"₹35,742.65",
    
    },
    {
    img:"https://imgaz2.staticbg.com/thumb/gallery/oaupload/banggood/images/7C/24/240e1f18-399e-471f-8817-9f5da3ed7119.jpg.webp",
    mob_name:"Xiaomi Mi 11 Lite 5G NE Global",
    price:"₹32,557.60",
    strikeoff_price:"₹37,996.82",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/01/C8/30fa0cc9-762a-4152-b173-b02655b489fd.jpg.webp",
    mob_name:"Xiaomi 11T Pro Global Version",
    price:"₹42,659.01",
    strikeoff_price:"₹58,199.63",
    
    },
    {
    img:"https://imgaz2.staticbg.com/thumb/gallery/oaupload/banggood/images/83/65/6c1317f2-262f-4c4c-9ce8-159e9e541752.jpg.webp",
    mob_name:"POCO M3 Pro 5G NFC Global",
    price:"₹18,571.04",
    strikeoff_price:"₹20,902.14",
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/9A/C0/59fef509-fcf2-47db-b80a-3c1e8b58bbb9.jpg.webp",
    mob_name:"Original OnePlus 8T 5G Global",
    price:"₹52760.41",
    strikeoff_price:"₹55868.54",
    
    },
    {
    img:"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/23/90/8defb849-77a7-4bfe-9131-bded63731a48.jpg.webp",
    mob_name:"POCO M4 Pro 5G NFC Global",
    price:"₹22,456.20",
    strikeoff_price:"₹25,564.32",
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/F0/9C/fb32a5d4-f4d8-4b47-9704-da5c7a3c33e1.jpg.webp",
    mob_name:"UMIDIGI A11 Pro Max Global",
    price:"₹17,870.94",
    strikeoff_price:"₹20,202.03",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/70/D6/f2fc2907-dfa2-4da8-ae97-5b43e6d31b82.jpg.webp",
    mob_name:"Xiaomi Mi 11 Lite 5G NE Global",
    price:"₹29,449.48",
    strikeoff_price:"₹34,888.70",
    
    },
    {
    img:"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/73/D8/410deb97-31ed-499c-aef2-5eaffc2212c2.jpg.webp",
    mob_name:"Xiaomi 11T Global Version 6.67 inch",
    price:"₹44,990.10",
    strikeoff_price:"₹46,544.16",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/4E/28/071af620-90ec-4d60-99a3-d544ffed0e08.jpg.webp",
    mob_name:"Xioami MI 11 Lite 5G NE Global",
    price:"35,410.08",
    strikeoff_price:"41,104.94",
    
    },
    {
    img:"https://imgaz2.staticbg.com/thumb/gallery/oaupload/banggood/images/F7/9A/ad660aff-7cc3-485b-8792-5d0374b249ba.jpg.webp",
    mob_name:"OUKITEL WP15 5G Global Bands",
    price:"₹28,749.37",
    strikeoff_price:"₹31,080.47",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/5F/C2/60263a0e-b321-4c06-b787-00dbc71ec7f8.jpg.webp",
    mob_name:"Xiaomi Redmi Note 10S Global",
    price:"₹25,564.32",
    strikeoff_price:"₹27,895.42",
    
    },
    {
    img:"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/A2/51/a4bb6179-0f1b-4d16-9544-0d59c2fe546b.jpg.webp",
    mob_name:"Xiaomi Redmi 9A Global Version",
    price:"₹9,246.67",
    strikeoff_price:"₹11,577.76",
    
    },
    {
    img:"https://imgaz2.staticbg.com/thumb/gallery/oaupload/banggood/images/55/B9/56fe86a8-a6a5-4d55-9f33-ff5949a65356.jpg.webp",
    mob_name:"DOOGEE S96 Pro Global Bands IP68",
    price:"₹23,310.16",
    strikeoff_price:"₹25,641.25",
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/C7/79/35f7e1cc-4329-4654-8d54-5fa8ebf36dd6.jpg.webp",
    mob_name:"OUKITEL C21 Pro Global Version",
    price:"₹11,654.69",
    strikeoff_price:"₹13,985.78",
    
    },
    {
    img:"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/F0/70/a66d4775-55be-436d-8023-c6483c13421e.jpg.webp",
    mob_name:"POCO X3 GT 5G 8GB 128GB",
    price:"₹27,195.31",
    strikeoff_price:"₹31,080.47",
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/9E/B4/e48da4e6-635f-4a96-a22c-fc1e46706bef.jpg.webp",
    mob_name:"POCO M4 Pro 5G NFC Global",
    price:"₹20,902.14",
    strikeoff_price:"₹23,233.23",
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/B3/07/a730b1fa-dacf-4fd5-b2db-794c904c5374.jpg.webp",
    mob_name:"Ulefone Armor 11T 5G FLIR Thermal",
    price:"₹45,844.06",
    strikeoff_price:"₹46,621.09",
    
    },
    {
    img:"https://imgaz.staticbg.com/thumb/gallery/oaupload/banggood/images/28/57/2d5a004c-9229-477b-bf62-b4599be02725.jpg.webp",
    mob_name:"OnePlus 9 5G Global Rom 8GB",
    price:"₹53,537.44",
    strikeoff_price:"₹61,307.75",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/ED/79/a5e34f3e-a076-4bc3-82f8-56b0a0a1013c.png.webp",
    mob_name:"BlackView BV8800 Global Bands",
    price:"₹31,080.47",
    strikeoff_price:"₹38,850.75",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/21/FC/0fa649ca-34f6-41e5-8899-6f5e4fc7c421.jpg.webp",
    mob_name:"Xiaomi Redmi Note 11 Pro 5G",
    price:"₹25,564.32",
    strikeoff_price:"₹34,888.70",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/80/C6/66f5fdd9-448d-45c4-87e3-6ec04c8e3ad5.jpg.webp",
    mob_name:"OUKITEL WP17 Global Bands Helio",
    price:"₹23,310.16",
    strikeoff_price:"₹25,641.25",
    
    },
    {
    img:"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/C3/9C/89fe80f7-3a68-41b6-b021-bb429853cbc1.jpg.webp",
    mob_name:"Xiaomi Redmi 9C Global Version",
    price:"₹12,347.02",
    strikeoff_price:"₹14,685.89",
    
    },
    {
    img:"https://imgaz1.staticbg.com/thumb/gallery/oaupload/banggood/images/6F/2D/bf9fee59-83a7-4fbc-9ad9-efc17e72741a.jpg.webp",
    mob_name:"UMIDIGI A11 Global Version",
    price:"₹13,208.75",
    strikeoff_price:"₹15,539.84",
    
    },
    {
        img:"https://imgaz3.staticbg.com/thumb/gallery/oaupload/banggood/images/FF/D5/c396e7e1-d358-4635-898c-4537a4cf6b8b.jpg.webp",
        mob_name:"POCO M4 Pro 4G Global Version",
        price:"₹19,333.21",
        strikeoff_price:"₹30,979.71",
    },
    {
        img:"https://imgaz2.staticbg.com/thumb/gallery/oaupload/banggood/images/FE/BE/525e460f-581a-46ee-b737-1fe3d9492492.jpg.webp",
        mob_name:"Xiaomi Redmi Note 10 Pro Global",
        price:"₹26,397.98",
        strikeoff_price:"₹28,727.28",
    }
    ];
    
    var cartData = JSON.parse(localStorage.getItem("cart")) || [];
    mobobj.map(function (elem) {
        var box = document.createElement("div");
    
        var img = document.createElement("img");
        img.src = elem.img;
    
        var name = document.createElement("p");
        name.textContent = elem.mob_name;
        
    
        var price = document.createElement("p");
        price.innerText =elem.price;
        var strikeoff=document.createElement("p");
        strikeoff.innerText=elem.strikeoff_price;
        strikeoff.style.textDecoration="line-through";
    
       
        box.append(img, name, price,strikeoff);
    
        document.querySelector("#container").append(box);
      });
    
      function addToCart(elem) {
        console.log(elem);
        cartData.push(elem);
        localStorage.setItem("cart", JSON.stringify(cartData));
        alert("item added to cart");
      }
    